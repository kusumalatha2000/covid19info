
 var TelegramBot = require('node-telegram-bot-api');
 var request = require('request');
 var apikey = "1336552960:AAH3uIDLAhW_gzQ8JmHnsSGzRsA0qFyJZbs";
 var bot = new TelegramBot(apikey, {polling: true});
 
bot.on('message',function(a){
	var ms = a.text
	request('https://coronavirus-19-api.herokuapp.com/countries/'+ms,function(err,response,body){
		 if(err) {
		 	console.log(err)
		 }
		 else if(body == "Country not found") {
		 	bot.sendMessage(a.chat.id,"please enter valid country name")

		 }
		 else {
		 	bot.sendMessage(a.chat.id,"cases: " + JSON.parse(body).cases + "\n" + "Today Cases: " + JSON.parse(body).todayCases + "\n" + "Deaths: " + JSON.parse(body).deaths + "\n" + "Today Deaths: " + JSON.parse(body).todayDeaths + "\n" + "Recovered: " + JSON.parse(body).recovered + "\n" + "critical: " + JSON.parse(body).critical)
		 }
	

	})
})



